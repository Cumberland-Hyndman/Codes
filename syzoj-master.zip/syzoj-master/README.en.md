<p align="center"><img src="static/self/syzoj.svg" width="250"></p>

[中文](README.md) | English

An online judge system for algorithm competition.

This project is based on [@louchenyao](https://github.com/louchenyao)'s [SYZOJ](https://github.com/Zhengzhou-11-Highschool/syzoj). Currently maintained by [LibreOJ](https://loj.ac).

# Deploying
Currently, the tutorial for deploying is only available in Chinese. It's [部署指南](https://github.com/syzoj/syzoj/wiki/%E9%83%A8%E7%BD%B2%E6%8C%87%E5%8D%97) in this project's wiki.

Join QQ group [565280992](https://jq.qq.com/?_wv=1027&k=5JQZWwd) or Telegram group [@lojdev](https://t.me/lojdev) for help.

# Upgrading
Currently, the tutorial for upgrading is only available in Chinese. It's [更新指南](https://github.com/syzoj/syzoj/wiki/%E6%9B%B4%E6%96%B0%E6%8C%87%E5%8D%97) in this project's wiki.

